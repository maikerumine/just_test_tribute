  ____             _   _       __  __
 |  _ \  ___  __ _| |_| |__   |  \/  | ___  ___ ___  __ _  __ _  ___  ___
 | | | |/ _ \/ _` | __| '_ \  | |\/| |/ _ \/ __/ __|/ _` |/ _` |/ _ \/ __|
 | |_| |  __/ (_| | |_| | | | | |  | |  __/\__ \__ \ (_| | (_| |  __/\__ \
 |____/ \___|\__,_|\__|_| |_| |_|  |_|\___||___/___/\__,_|\__, |\___||___/
                                                          |___/

A Minetest mod which sends a chat message when a player dies.

Version: 0.1.3
License: GPL v3 (see LICENSE.txt)

Dependencies:
none

Please report bugs at the github issue tracker:
https://github.com/4Evergreen4/death_messages/issues/
